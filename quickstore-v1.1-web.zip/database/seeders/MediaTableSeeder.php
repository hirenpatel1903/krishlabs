<?php
namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Seeder;
use Faker\Generator as Faker;

class MediaTableSeeder extends Seeder
{
    public function run()
    {

    }
}
