<?php
namespace App\Enums;

interface Units
{
    const KG   = 5;
    const GM = 10;
    const PCS = 15;
}
