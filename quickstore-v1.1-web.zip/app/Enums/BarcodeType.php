<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 2/16/20
 * Time: 5:21 PM
 */

namespace App\Enums;

interface BarcodeType
{
    const C39 = 'C39';
    const S25   = 'S25';
    const I25   = 'I25';
    const MSI   = 'MSI+';
    const POSTNET   = 'POSTNET';

}
