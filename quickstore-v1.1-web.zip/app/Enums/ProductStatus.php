<?php
/**
 * Created by PhpStorm.
 * User: dipok
 * Date: 19/4/20
 * Time: 2:28 PM
 */

namespace App\Enums;


class ProductStatus
{
    const ACTIVE        = 5;
    const INACTIVE      = 10;
}