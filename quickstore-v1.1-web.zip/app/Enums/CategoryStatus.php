<?php
/**
 * Created by PhpStorm.
 * User: dipok
 * Date: 19/4/20
 * Time: 2:26 PM
 */

namespace App\Enums;


interface CategoryStatus
{
    const ACTIVE   = 5;
    const INACTIVE = 10;
}