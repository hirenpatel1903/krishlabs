<?php
/**
 * Created by PhpStorm.
 * User: dipok
 * Date: 24/4/20
 * Time: 9:38 AM
 */

namespace App\Enums;


interface UpdateStatus
{
    const SUCCESS = 5;
    const FAIL    = 10;
}