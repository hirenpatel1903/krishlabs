<?php

namespace App\Enums;
interface ProductType
{
    const SINGLE = 5;
    const VARIATION = 10;
}
