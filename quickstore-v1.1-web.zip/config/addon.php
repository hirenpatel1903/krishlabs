<?php
/**
 * Created by PhpStorm.
 * User: dipok
 * Date: 24/4/20
 * Time: 8:59 PM
 */

return [
    'file_extract_path' => storage_path('app/addon/'),

    'upload_path' => public_path('uploads/addons/'),

    'extract_path' => public_path('uploads/addons/'),

    'root_path' => public_path(),
];
