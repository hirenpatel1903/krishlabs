<?php
/**
 * Created by PhpStorm.
 * User: dipok
 * Date: 24/4/20
 * Time: 8:59 PM
 */

return [

    'version' => 'MS4zOmZvb2QtYmFuaw==',

    'project_name'  => 'food-bank-web',

    'update_url'    => 'https://demo.quickstore.xyz/',

    'file_url'      => 'https://demo.quickstore.xyz/',

    'file_extract_path' => storage_path('app/update/'),

    'addon_extract_path' => public_path('uploads/'),

    'addon_upload_path' => public_path('uploads/'),

    'root_path' => public_path(),
];
