<?php return array (
  'customer-post-form' => 'App\\Http\\Livewire\\CustomerPostForm',
  'order-tax' => 'App\\Http\\Livewire\\OrderTax',
  'pos-form' => 'App\\Http\\Livewire\\PosForm',
  'pos-model.add-customer' => 'App\\Http\\Livewire\\PosModel\\AddCustomer',
  'pos-model.add-payment' => 'App\\Http\\Livewire\\PosModel\\AddPayment',
  'pos-model.edit-cart-item' => 'App\\Http\\Livewire\\PosModel\\EditCartItem',
  'pos-model.order-tax' => 'App\\Http\\Livewire\\PosModel\\OrderTax',
  'pos-model.print-order' => 'App\\Http\\Livewire\\PosModel\\PrintOrder',
);